package com.example.autoanswer

import android.app.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.abs

private class Line(val text: String, val box: Rect, val n: String)
private class Run(val start: Int, val texts: List<String>, var rect: RectF?) { var miss = 0 }

class ScreenService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var marker: MarkerView
    private lateinit var card: TextView
    private lateinit var wm: WindowManager
    private val cardBg = GradientDrawable()

    private var apiKey = ""
    private var model = "openrouter/auto"
    private var realW = 0
    private var realH = 0
    private var lastKey: Set<String> = emptySet()
    private var lines: List<Line> = emptyList()
    private var runs: List<Run> = emptyList()
    private var markerColor = GREEN
    private var cardShown = false
    private var thinking = false
    private var dots = 0
    private var lastAnswer = ""
    private var lastCardText: CharSequence = ""
    private val history = ArrayDeque<String>()
    @Volatile private var busy = false
    private var running = true

    companion object {
        val GREEN = Color.rgb(46, 204, 113)
        val AMBER = Color.rgb(255, 193, 7)
        val RED = Color.rgb(231, 76, 60)
    }

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }
    private fun tone(conf: Int): Int = when {
        conf < 0 -> GREEN
        conf >= 70 -> GREEN
        conf >= 40 -> AMBER
        else -> RED
    }
    private fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun realSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            Pair(m.widthPixels, m.heightPixels)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || ::marker.isInitialized) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val ch = "scr"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(ch, "AutoAnswer", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, ch).setContentTitle("AutoAnswer работает")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notif)
        }

        apiKey = intent.getStringExtra("key") ?: ""
        model = intent.getStringExtra("model")?.ifBlank { null } ?: "openrouter/auto"
        val data = intent.getParcelableExtra<Intent>("data")!!
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(intent.getIntExtra("code", Activity.RESULT_OK), data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, main)

        val size = realSize()
        realW = size.first
        realH = size.second
        reader = ImageReader.newInstance(realW, realH, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "cap", realW, realH, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )
        setupOverlay()
        loop()
        return START_NOT_STICKY
    }

    private fun setupOverlay() {
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        marker = MarkerView(this)
        val mlp = WindowManager.LayoutParams(
            realW, realH, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        wm.addView(marker, mlp)

        cardBg.setColor(Color.argb(238, 18, 22, 32))
        cardBg.cornerRadius = dp(18).toFloat()
        cardBg.setStroke(dp(1), withAlpha(GREEN, 120))
        card = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            maxLines = 14
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = cardBg
            visibility = View.GONE
        }
        val clp = WindowManager.LayoutParams(
            realW - dp(32), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(48)
        }
        card.setOnClickListener { copyAnswer() }
        card.setOnLongClickListener { hideCard(); true }
        wm.addView(card, clp)
    }

    // ---------- карточка с ответом ----------
    private val dotsTick = object : Runnable {
        override fun run() {
            if (!thinking) return
            dots = (dots + 1) % 4
            card.text = "Думаю" + ".".repeat(dots)
            main.postDelayed(this, 350)
        }
    }

    private fun showCard(t: CharSequence, think: Boolean = false) {
        main.removeCallbacks(dotsTick)
        thinking = think
        dots = 0
        card.text = t
        if (!cardShown) {
            cardShown = true
            card.animate().cancel()
            card.visibility = View.VISIBLE
            card.alpha = 0f
            card.translationY = dp(40).toFloat()
            card.animate().alpha(1f).translationY(0f).setDuration(350)
                .setInterpolator(DecelerateInterpolator()).start()
        }
        if (think) main.postDelayed(dotsTick, 350)
    }

    private fun hideCard() {
        main.removeCallbacks(dotsTick)
        thinking = false
        if (!cardShown) return
        cardShown = false
        card.animate().cancel()
        card.animate().alpha(0f).translationY(dp(40).toFloat()).setDuration(250)
            .withEndAction { if (!cardShown) card.visibility = View.GONE }.start()
    }

    private fun copyAnswer() {
        if (lastAnswer.isEmpty()) return
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("answer", lastAnswer))
        Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
    }

    private fun buildCardText(marked: Boolean, body: String, why: String, conf: Int): CharSequence {
        val ex = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        val sb = SpannableStringBuilder((if (marked) "✓ " else "") + body)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, ex)
        if (why.isNotBlank()) {
            val s = sb.length
            sb.append("\n").append(why.trim())
            sb.setSpan(ForegroundColorSpan(Color.argb(210, 255, 255, 255)), s, sb.length, ex)
            sb.setSpan(RelativeSizeSpan(0.85f), s, sb.length, ex)
        }
        if (conf in 0..100) {
            val s = sb.length
            sb.append("\nУверенность: $conf%")
            sb.setSpan(ForegroundColorSpan(tone(conf)), s, sb.length, ex)
            sb.setSpan(RelativeSizeSpan(0.8f), s, sb.length, ex)
        }
        val h = sb.length
        sb.append("\n\nнажми — скопировать · удерживай — закрыть")
        sb.setSpan(ForegroundColorSpan(Color.argb(140, 255, 255, 255)), h, sb.length, ex)
        sb.setSpan(RelativeSizeSpan(0.7f), h, sb.length, ex)
        return sb
    }

    // ---------- захват и распознавание ----------
    private fun loop() {
        if (!running) return
        val bmp = grab()
        if (bmp != null) recognize(bmp)
        main.postDelayed({ loop() }, 2000)
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        img.use {
            val p = it.planes[0]
            val rowPad = p.rowStride - p.pixelStride * it.width
            val full = Bitmap.createBitmap(it.width + rowPad / p.pixelStride, it.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(p.buffer)
            return Bitmap.createBitmap(full, 0, 0, it.width, it.height)
        }
    }

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[b.length]
    }

    /** Нечёткое совпадение строк: OCR каждый раз читает чуть по-разному. */
    private fun matches(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length < 4 || b.length < 4) return false
        val mx = maxOf(a.length, b.length)
        if (abs(a.length - b.length) > mx / 4) return false
        return lev(a, b) <= mx / 5
    }

    private fun similar(a: Set<String>, b: Set<String>): Boolean {
        if (a.isEmpty() || b.isEmpty()) return false
        val added = a.count { x -> x !in b && b.none { y -> matches(x, y) } }
        val removed = b.count { y -> y !in a && a.none { x -> matches(x, y) } }
        return added + removed <= 2
    }

    private fun recognize(bmp: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { r ->
                val cardTop = if (cardShown && card.height > 0) realH - dp(48) - card.height - dp(4) else Int.MAX_VALUE
                val list = ArrayList<Line>()
                for (b in r.textBlocks) {
                    for (l in b.lines) {
                        val box = l.boundingBox ?: continue
                        if (box.bottom > cardTop) continue
                        list.add(Line(l.text, box, norm(l.text)))
                    }
                }
                list.sortBy { it.box.top }
                lines = list
                updateMarker()          // рамка следит за вариантом на каждом кадре
                if (busy) return@addOnSuccessListener

                val key = list.map { it.n }.filter { it.length > 1 }.toSet()
                val full = list.joinToString("\n") { it.text }.trim()
                val changed = !similar(key, lastKey)

                // страница сменилась целиком — старая рамка больше не нужна
                if (changed && lastKey.isNotEmpty()) {
                    val gone = lastKey.count { x -> x !in key && key.none { y -> matches(x, y) } }
                    if (gone >= 4 && gone * 2 >= lastKey.size) { runs = emptyList(); marker.hide() }
                }
                if (full.length < 20) {
                    if (changed) lastKey = key
                    return@addOnSuccessListener
                }
                if (!changed) return@addOnSuccessListener

                lastKey = key
                busy = true
                if (lastAnswer.isEmpty()) showCard("Думаю", true)
                else showCard(TextUtils.concat(lastCardText, "\n⏳ Новый вопрос, думаю…"))

                val snapshot = ArrayList(list)
                val numbered = snapshot.take(120).mapIndexed { i, l -> "$i: ${l.text}" }.joinToString("\n")
                val context = history.toList()
                history.addLast(full.take(1500))
                while (history.size > 5) history.removeFirst()
                val prompt = buildString {
                    if (context.isNotEmpty()) {
                        append("Предыдущие экраны этого же задания (от старых к новым), только как контекст:\n")
                        context.forEachIndexed { i, t -> append("--- экран ${i + 1} ---\n").append(t).append("\n") }
                        append("\n")
                    }
                    append("=== ТЕКУЩИЙ ЭКРАН (номера строк относятся только к нему) ===\n").append(numbered)
                }
                io.execute {
                    val raw = try { ask(prompt) } catch (e: Exception) { "ERR:" + e.message }
                    main.post { handleAnswer(raw, snapshot) }
                }
            }
            .addOnCompleteListener { bmp.recycle() }
    }

    private fun handleAnswer(raw: String, snapshot: List<Line>) {
        busy = false
        if (raw.startsWith("ERR:")) {
            val msg = "⚠ " + raw.removePrefix("ERR:").take(180)
            if (lastAnswer.isEmpty()) showCard(msg) else showCard(TextUtils.concat(lastCardText, "\n", msg))
            main.postDelayed({ lastKey = emptySet() }, 8000)
            return
        }
        var answer = raw.trim()
        var why = ""
        var conf = -1
        val idx = ArrayList<Int>()
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s >= 0 && e > s) {
            try {
                val j = JSONObject(raw.substring(s, e + 1))
                answer = j.optString("answer", "").trim()
                why = j.optString("why", "").trim()
                conf = j.optInt("confidence", -1)
                val arr = j.optJSONArray("lines")
                if (arr != null) for (k in 0 until arr.length()) idx.add(arr.optInt(k, -1))
            } catch (ex: Exception) {
                // оставляем сырой текст
            }
        }
        val newRuns = buildRuns(idx, snapshot)
        if (newRuns.isNotEmpty()) runs = newRuns
        else if (answer.isNotEmpty()) runs = emptyList()   // ответ нужно вписать, вариантов нет
        // если вопроса нет — старая рамка остаётся, пока вариант виден на экране

        if (answer.isEmpty() && newRuns.isEmpty()) {
            if (lastAnswer.isEmpty()) hideCard() else showCard(lastCardText)
        } else {
            val marked = newRuns.flatMap { r -> (r.start until r.start + r.texts.size).map { snapshot[it].text } }
                .joinToString("\n")
            val body = answer.ifEmpty { marked }
            markerColor = tone(conf)
            cardBg.setStroke(dp(1), withAlpha(markerColor, 140))
            lastAnswer = body
            lastCardText = buildCardText(newRuns.isNotEmpty(), body, why, conf)
            showCard(lastCardText)
        }
        updateMarker()
    }

    private fun mk(cur: List<Int>, snap: List<Line>): Run {
        val u = RectF(snap[cur.first()].box)
        for (k in 1 until cur.size) u.union(RectF(snap[cur[k]].box))
        return Run(cur.first(), cur.map { snap[it].n }, u)
    }

    private fun buildRuns(idx: List<Int>, snap: List<Line>): List<Run> {
        val sorted = idx.filter { it in snap.indices }.distinct().sorted()
        val out = ArrayList<Run>()
        var cur = ArrayList<Int>()
        for (i in sorted) {
            if (cur.isNotEmpty() && i != cur.last() + 1) {
                out.add(mk(cur, snap))
                cur = ArrayList()
            }
            cur.add(i)
        }
        if (cur.isNotEmpty()) out.add(mk(cur, snap))
        return out
    }

    private fun locate(run: Run): RectF? {
        val n = run.texts.size
        val ref = run.rect
        fun dist(i: Int): Float =
            if (ref != null) abs(lines[i].box.centerY() - ref.centerY()) else abs(i - run.start).toFloat()

        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in 0..(lines.size - n)) {
            var ok = true
            for (k in 0 until n) {
                if (!matches(lines[i + k].n, run.texts[k])) { ok = false; break }
            }
            if (!ok) continue
            val dd = dist(i)
            if (dd < bestD) { bestD = dd; best = i }
        }
        if (best >= 0) {
            val u = RectF(lines[best].box)
            for (k in 1 until n) u.union(RectF(lines[best + k].box))
            return u
        }
        if (n > 1) {   // запасной вариант: нашли хотя бы первую строку варианта
            for (i in lines.indices) {
                if (!matches(lines[i].n, run.texts[0])) continue
                val dd = dist(i)
                if (dd < bestD) { bestD = dd; best = i }
            }
            if (best >= 0) return RectF(lines[best].box)
        }
        return null
    }

    private fun updateMarker() {
        if (runs.isEmpty()) { marker.hide(); return }
        val rects = ArrayList<RectF>()
        for (run in runs) {
            val found = locate(run)
            if (found != null) { run.rect = found; run.miss = 0 } else run.miss++
            val rr = run.rect
            // не гасим рамку из-за одного-двух неудачных кадров распознавания
            if (rr != null && run.miss < 4) rects.add(rr)
        }
        if (rects.isEmpty()) marker.hide() else marker.show(rects, markerColor)
    }

    private fun ask(userText: String): String {
        val sys = "Ты помощник для учебных заданий. Тебе дают пронумерованные строки текста с экрана телефона. " +
            "Могут быть и предыдущие экраны этого же задания (условие, прочитанный текст) — используй их как контекст. " +
            "Игнорируй элементы интерфейса: кнопки «Далее», «Назад», таймер, меню. " +
            "Определи тип задания: один верный вариант, несколько верных (если сказано «выберите все» или «несколько»), " +
            "ответ нужно вписать, или вопроса нет. Сначала в поле why кратко (1–2 предложения) обоснуй выбор, затем дай итог. " +
            "Верни ТОЛЬКО JSON: {\"why\":\"...\",\"answer\":\"краткий итог: текст верного варианта или вписываемый ответ\"," +
            "\"lines\":[номера строк верных вариантов; если вариант занимает несколько строк, перечисли все его строки; " +
            "пустой массив, если ответ вписывается],\"confidence\":число от 0 до 100}. " +
            "Если вопроса на экране нет: {\"why\":\"\",\"answer\":\"\",\"lines\":[],\"confidence\":0}. Отвечай на языке вопроса."
        val body = JSONObject()
            .put("model", model).put("max_tokens", 700).put("temperature", 0)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", sys))
                .put(JSONObject().put("role", "user").put("content", userText)))
        val c = URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer $apiKey")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val resp = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (c.responseCode >= 400) return "ERR:API ${c.responseCode}: $resp".take(300)
        return JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { wm.removeView(marker) } catch (e: Exception) {}
        try { wm.removeView(card) } catch (e: Exception) {}
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
