package com.example.autoanswer

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * Рамка вокруг правильного варианта: градиентная заливка, бегущий блик, пульсирующее свечение,
 * значок с галочкой и расходящимся кольцом. Плавно переезжает, если вариант сдвинулся на экране.
 */
class MarkerView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private var color = Color.rgb(46, 204, 113)

    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3 * d }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val badgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2 * d }
    private val tickP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4 * d; color = Color.WHITE
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val shimmerP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shimmerW = 90 * d
    private val shimmerShader = LinearGradient(
        0f, 0f, shimmerW, 0f, intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP
    )
    private val mat = Matrix()

    private var from: List<RectF> = emptyList()
    private var to: List<RectF> = emptyList()
    private var morph = 1f
    private var shown = false
    private var appear = 0f
    private var t = 0f
    private var appearAnim: ValueAnimator? = null
    private var morphAnim: ValueAnimator? = null

    private val loopAnim: ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    private fun withAlpha(c: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun currentRects(): List<RectF> {
        if (from.size != to.size) return to
        return to.indices.map { i ->
            val a = from[i]; val b = to[i]
            RectF(
                a.left + (b.left - a.left) * morph, a.top + (b.top - a.top) * morph,
                a.right + (b.right - a.right) * morph, a.bottom + (b.bottom - a.bottom) * morph
            )
        }
    }

    private fun differs(a: List<RectF>, b: List<RectF>): Boolean {
        for (i in a.indices) {
            if (abs(a[i].left - b[i].left) > 3 || abs(a[i].top - b[i].top) > 3 ||
                abs(a[i].right - b[i].right) > 3 || abs(a[i].bottom - b[i].bottom) > 3) return true
        }
        return false
    }

    fun show(newRects: List<RectF>, tone: Int = Color.rgb(46, 204, 113)) {
        if (newRects.isEmpty()) { hide(); return }
        color = tone
        val wasHidden = !shown
        shown = true
        if (wasHidden || to.size != newRects.size) {
            morphAnim?.cancel()
            from = newRects; to = newRects; morph = 1f
        } else if (differs(to, newRects)) {
            val start = currentRects()
            morphAnim?.cancel()
            from = start; to = newRects; morph = 0f
            morphAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 280
                interpolator = DecelerateInterpolator()
                addUpdateListener { morph = it.animatedValue as Float; invalidate() }
                start()
            }
        }
        if (wasHidden) {
            appearAnim?.cancel()
            appearAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 650
                interpolator = OvershootInterpolator(1.5f)
                addUpdateListener { appear = it.animatedValue as Float; invalidate() }
                start()
            }
        }
        if (!loopAnim.isRunning) loopAnim.start()
        invalidate()
    }

    fun hide() {
        if (!shown) return
        shown = false
        appearAnim?.cancel()
        appearAnim = ValueAnimator.ofFloat(appear, 0f).apply {
            duration = 280
            addUpdateListener { appear = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (!shown) {
                        loopAnim.cancel()
                        from = emptyList(); to = emptyList(); appear = 0f
                        invalidate()
                    }
                }
            })
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (to.isEmpty() || appear <= 0f) return
        val a = appear.coerceIn(0f, 1f)
        val pulse = 0.5f + 0.5f * sin(2.0 * PI * t).toFloat()
        val rects = currentRects()
        for (r in rects) {
            val box = RectF(r.left - 10 * d, r.top - 5 * d, r.right + 10 * d, r.bottom + 5 * d)
            val cx = box.centerX()
            val cy = box.centerY()
            val rad = 14 * d
            canvas.save()
            canvas.scale(appear, appear, cx, cy)

            // заливка-градиент
            fillP.shader = LinearGradient(
                0f, box.top, 0f, box.bottom,
                withAlpha(color, (75 * a).toInt()), withAlpha(color, (18 * a).toInt()), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(box, rad, rad, fillP)

            // бегущий блик
            val clip = Path().apply { addRoundRect(box, rad, rad, Path.Direction.CW) }
            canvas.save()
            canvas.clipPath(clip)
            mat.setTranslate(box.left - shimmerW + (box.width() + shimmerW) * t, 0f)
            shimmerShader.setLocalMatrix(mat)
            shimmerP.shader = shimmerShader
            shimmerP.alpha = (255 * a).toInt()
            canvas.drawRect(box, shimmerP)
            canvas.restore()

            // свечение и контур
            glowP.strokeWidth = (6 + 6 * pulse) * d
            glowP.color = withAlpha(color, ((40 + 90 * pulse) * a).toInt())
            canvas.drawRoundRect(box, rad, rad, glowP)
            strokeP.color = withAlpha(color, (255 * a).toInt())
            canvas.drawRoundRect(box, rad, rad, strokeP)

            // значок с галочкой слева (или справа, если слева нет места)
            val bx = if (box.left > 70 * d) box.left - 28 * d else box.right + 28 * d
            val br = 18 * d * (1f + 0.07f * pulse)
            ringP.color = withAlpha(color, ((1f - t) * 170 * a).toInt())
            canvas.drawCircle(bx, cy, br + t * 16 * d, ringP)
            badgeP.color = withAlpha(color, (255 * a).toInt())
            canvas.drawCircle(bx, cy, br, badgeP)

            val tick = Path().apply {
                moveTo(bx - 7 * d, cy)
                lineTo(bx - 2 * d, cy + 5.5f * d)
                lineTo(bx + 8 * d, cy - 5.5f * d)
            }
            val pm = PathMeasure(tick, false)
            val p = ((appear - 0.3f) / 0.7f).coerceIn(0f, 1f)
            val seg = Path()
            pm.getSegment(0f, pm.length * p, seg, true)
            tickP.alpha = (255 * a).toInt()
            canvas.drawPath(seg, tickP)

            canvas.restore()
        }
    }
}
