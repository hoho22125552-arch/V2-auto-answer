package com.example.autoanswer

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.OvershootInterpolator

/** Рисует зелёную рамку с пульсирующим свечением и анимированной галочкой вокруг правильного варианта. */
class MarkerView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val green = Color.rgb(46, 204, 113)

    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3 * d; color = green }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = green }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = green }
    private val badgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = green }
    private val tickP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4 * d; color = Color.WHITE
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    private var rects: List<RectF> = emptyList()
    private var shown = false
    private var appear = 0f
    private var pulse = 0f
    private var appearAnim: ValueAnimator? = null

    private val pulseAnim: ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
    }

    fun show(newRects: List<RectF>) {
        if (newRects.isEmpty()) { hide(); return }
        val wasHidden = !shown
        shown = true
        rects = newRects
        if (wasHidden) {
            appearAnim?.cancel()
            appearAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 650
                interpolator = OvershootInterpolator(1.5f)
                addUpdateListener { appear = it.animatedValue as Float; invalidate() }
                start()
            }
        }
        if (!pulseAnim.isRunning) pulseAnim.start()
        invalidate()
    }

    fun hide() {
        if (!shown) return
        shown = false
        appearAnim?.cancel()
        pulseAnim.cancel()
        appearAnim = ValueAnimator.ofFloat(appear, 0f).apply {
            duration = 250
            addUpdateListener { appear = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (!shown) { rects = emptyList(); appear = 0f; invalidate() }
                }
            })
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (rects.isEmpty() || appear <= 0f) return
        val a = appear.coerceIn(0f, 1f)
        for (r in rects) {
            val box = RectF(r.left - 8 * d, r.top - 4 * d, r.right + 8 * d, r.bottom + 4 * d)
            val cx = box.centerX()
            val cy = box.centerY()
            canvas.save()
            canvas.scale(appear, appear, cx, cy)
            val rad = 12 * d

            fillP.alpha = (45 * a).toInt()
            canvas.drawRoundRect(box, rad, rad, fillP)

            glowP.strokeWidth = (6 + 6 * pulse) * d
            glowP.alpha = ((40 + 90 * pulse) * a).toInt().coerceIn(0, 255)
            canvas.drawRoundRect(box, rad, rad, glowP)

            strokeP.alpha = (255 * a).toInt()
            canvas.drawRoundRect(box, rad, rad, strokeP)

            // значок с галочкой слева от варианта (или справа, если слева нет места)
            val bx = if (box.left > 70 * d) box.left - 28 * d else box.right + 28 * d
            val br = 18 * d * (1f + 0.08f * pulse)
            badgeP.alpha = (255 * a).toInt()
            canvas.drawCircle(bx, cy, br, badgeP)

            val tick = Path().apply {
                moveTo(bx - 7 * d, cy)
                lineTo(bx - 2 * d, cy + 5.5f * d)
                lineTo(bx + 8 * d, cy - 5.5f * d)
            }
            val pm = PathMeasure(tick, false)
            val p = ((appear - 0.3f) / 0.7f).coerceIn(0f, 1f)
            val seg = Path()
            pm.getSegment(0f, pm.length * p, seg, true)
            tickP.alpha = (255 * a).toInt()
            canvas.drawPath(seg, tickP)

            canvas.restore()
        }
    }
}
