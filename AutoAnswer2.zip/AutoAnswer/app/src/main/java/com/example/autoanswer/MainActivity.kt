package com.example.autoanswer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var keyField: EditText
    private lateinit var modelField: EditText
    private val REQ_CAPTURE = 1

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        keyField = EditText(this).apply {
            hint = "API ключ OpenRouter (sk-or-...)"
            setText(prefs.getString("key", ""))
        }
        val start = Button(this).apply { text = "Старт" }
        val stop = Button(this).apply { text = "Стоп" }
        modelField = EditText(this).apply {
            hint = "Модель"
            setText(prefs.getString("model", "openrouter/auto"))
        }
        root.addView(keyField); root.addView(modelField); root.addView(start); root.addView(stop)
        setContentView(root)

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Дай разрешение «Поверх других окон» и нажми Старт снова", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            prefs.edit().putString("key", keyField.text.toString().trim())
                .putString("model", modelField.text.toString().trim()).apply()
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
        }
        stop.setOnClickListener { stopService(Intent(this, ScreenService::class.java)) }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_CAPTURE && res == RESULT_OK && data != null) {
            val i = Intent(this, ScreenService::class.java)
                .putExtra("code", res).putExtra("data", data)
                .putExtra("key", keyField.text.toString().trim())
                .putExtra("model", modelField.text.toString().trim())
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
