package com.example.autoanswer

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.abs

private data class Line(val text: String, val box: Rect)
private data class Run(val start: Int, val texts: List<String>)

class ScreenService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var marker: MarkerView
    private lateinit var card: TextView
    private lateinit var wm: WindowManager

    private var apiKey = ""
    private var model = "openrouter/auto"
    private var realW = 0
    private var realH = 0
    private var lastKey: Set<String> = emptySet()
    private var lines: List<Line> = emptyList()
    private var runs: List<Run> = emptyList()
    private var cardShown = false
    private var thinking = false
    private var dots = 0
    @Volatile private var busy = false
    private var running = true

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun realSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            Pair(m.widthPixels, m.heightPixels)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || ::marker.isInitialized) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val ch = "scr"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(ch, "AutoAnswer", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, ch).setContentTitle("AutoAnswer работает")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notif)
        }

        apiKey = intent.getStringExtra("key") ?: ""
        model = intent.getStringExtra("model")?.ifBlank { null } ?: "openrouter/auto"
        val data = intent.getParcelableExtra<Intent>("data")!!
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(intent.getIntExtra("code", Activity.RESULT_OK), data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, main)

        val size = realSize()
        realW = size.first
        realH = size.second
        reader = ImageReader.newInstance(realW, realH, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "cap", realW, realH, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )
        setupOverlay()
        loop()
        return START_NOT_STICKY
    }

    private fun setupOverlay() {
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        marker = MarkerView(this)
        val mlp = WindowManager.LayoutParams(
            realW, realH, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        wm.addView(marker, mlp)

        card = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.argb(235, 18, 22, 32))
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.argb(110, 46, 204, 113))
            }
            visibility = View.GONE
        }
        val clp = WindowManager.LayoutParams(
            realW - dp(32), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(48)
        }
        wm.addView(card, clp)
    }

    // ---------- карточка с ответом ----------
    private val dotsTick = object : Runnable {
        override fun run() {
            if (!thinking) return
            dots = (dots + 1) % 4
            card.text = "Думаю" + ".".repeat(dots)
            main.postDelayed(this, 350)
        }
    }

    private fun showCard(t: String, think: Boolean = false) {
        main.removeCallbacks(dotsTick)
        thinking = think
        dots = 0
        card.text = t
        if (!cardShown) {
            cardShown = true
            card.animate().cancel()
            card.visibility = View.VISIBLE
            card.alpha = 0f
            card.translationY = dp(40).toFloat()
            card.animate().alpha(1f).translationY(0f).setDuration(350)
                .setInterpolator(DecelerateInterpolator()).start()
        }
        if (think) main.postDelayed(dotsTick, 350)
    }

    private fun hideCard() {
        main.removeCallbacks(dotsTick)
        thinking = false
        if (!cardShown) return
        cardShown = false
        card.animate().cancel()
        card.animate().alpha(0f).translationY(dp(40).toFloat()).setDuration(250)
            .withEndAction { if (!cardShown) card.visibility = View.GONE }.start()
    }

    // ---------- захват и распознавание ----------
    private fun loop() {
        if (!running) return
        if (!busy) {
            val bmp = grab()
            if (bmp != null) recognize(bmp)
        }
        main.postDelayed({ loop() }, 2000)
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        img.use {
            val p = it.planes[0]
            val rowPad = p.rowStride - p.pixelStride * it.width
            val full = Bitmap.createBitmap(it.width + rowPad / p.pixelStride, it.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(p.buffer)
            return Bitmap.createBitmap(full, 0, 0, it.width, it.height)
        }
    }

    private fun similar(a: Set<String>, b: Set<String>): Boolean {
        if (a.isEmpty() || b.isEmpty()) return false
        val added = a.count { it !in b }
        val removed = b.count { it !in a }
        return added + removed <= 2
    }

    private fun recognize(bmp: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { r ->
                val cardTop = if (cardShown && card.height > 0) realH - dp(48) - card.height - dp(4) else Int.MAX_VALUE
                val list = ArrayList<Line>()
                for (b in r.textBlocks) {
                    for (l in b.lines) {
                        val box = l.boundingBox ?: continue
                        if (box.bottom > cardTop) continue
                        list.add(Line(l.text, box))
                    }
                }
                list.sortBy { it.box.top }
                lines = list
                updateMarker()

                val key = list.map { norm(it.text) }.filter { it.length > 1 }.toSet()
                val full = list.joinToString("\n") { it.text }.trim()
                val changed = !similar(key, lastKey)
                if (full.length < 20) {
                    if (changed) { lastKey = key; runs = emptyList(); marker.hide(); hideCard() }
                    return@addOnSuccessListener
                }
                if (!changed) return@addOnSuccessListener

                lastKey = key
                busy = true
                runs = emptyList()
                marker.hide()
                showCard("Думаю", true)
                val snapshot = ArrayList(list)
                val numbered = snapshot.take(120).mapIndexed { i, l -> "$i: ${l.text}" }.joinToString("\n")
                io.execute {
                    val raw = try { ask(numbered) } catch (e: Exception) { "ERR:" + e.message }
                    main.post { handleAnswer(raw, snapshot) }
                }
            }
            .addOnCompleteListener { bmp.recycle() }
    }

    private fun handleAnswer(raw: String, snapshot: List<Line>) {
        busy = false
        if (raw.startsWith("ERR:")) {
            runs = emptyList()
            marker.hide()
            showCard("⚠ " + raw.removePrefix("ERR:").take(180))
            main.postDelayed({ lastKey = emptySet() }, 8000)
            return
        }
        var answer = raw.trim()
        val idx = ArrayList<Int>()
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s >= 0 && e > s) {
            try {
                val j = JSONObject(raw.substring(s, e + 1))
                answer = j.optString("answer", "").trim()
                val arr = j.optJSONArray("lines")
                if (arr != null) for (k in 0 until arr.length()) idx.add(arr.optInt(k, -1))
            } catch (ex: Exception) {
                // оставляем сырой текст
            }
        }
        runs = buildRuns(idx, snapshot)
        if (answer.isEmpty() && runs.isEmpty()) {
            hideCard()
        } else if (runs.isNotEmpty()) {
            showCard("✓ " + answer.ifEmpty { "Правильный вариант отмечен" })
        } else {
            showCard(answer)
        }
        updateMarker()
    }

    private fun buildRuns(idx: List<Int>, snap: List<Line>): List<Run> {
        val sorted = idx.filter { it in snap.indices }.distinct().sorted()
        val out = ArrayList<Run>()
        var cur = ArrayList<Int>()
        for (i in sorted) {
            if (cur.isNotEmpty() && i != cur.last() + 1) {
                out.add(Run(cur.first(), cur.map { norm(snap[it].text) }))
                cur = ArrayList()
            }
            cur.add(i)
        }
        if (cur.isNotEmpty()) out.add(Run(cur.first(), cur.map { norm(snap[it].text) }))
        return out
    }

    private fun findRun(run: Run): Int {
        var best = -1
        for (i in 0..(lines.size - run.texts.size)) {
            var ok = true
            for (k in run.texts.indices) {
                if (norm(lines[i + k].text) != run.texts[k]) { ok = false; break }
            }
            if (ok && (best < 0 || abs(i - run.start) < abs(best - run.start))) best = i
        }
        return best
    }

    private fun updateMarker() {
        if (runs.isEmpty()) { marker.hide(); return }
        val rects = ArrayList<RectF>()
        for (run in runs) {
            val i = findRun(run)
            if (i < 0) continue
            val u = RectF(lines[i].box)
            for (k in 1 until run.texts.size) u.union(RectF(lines[i + k].box))
            rects.add(u)
        }
        if (rects.isEmpty()) marker.hide() else marker.show(rects)
    }

    private fun ask(numberedLines: String): String {
        val sys = "Ты помогаешь с учебными заданиями. Тебе дают пронумерованные строки текста с экрана телефона. " +
            "Если на экране есть вопрос или тест — выбери правильный ответ. " +
            "Верни ТОЛЬКО JSON без пояснений: {\"answer\":\"краткий ответ в одну строку\",\"lines\":[номера строк правильных вариантов]}. " +
            "Если вариант ответа занимает несколько строк, перечисли все его строки. " +
            "Если вариантов нет и ответ нужно вписать — lines пустой массив, а ответ в answer. " +
            "Если вопроса на экране нет: {\"answer\":\"\",\"lines\":[]}. Отвечай на языке вопроса."
        val body = JSONObject()
            .put("model", model).put("max_tokens", 600)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", sys))
                .put(JSONObject().put("role", "user").put("content", numberedLines)))
        val c = URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer $apiKey")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val resp = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (c.responseCode >= 400) return "ERR:API ${c.responseCode}: $resp".take(300)
        return JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { wm.removeView(marker) } catch (e: Exception) {}
        try { wm.removeView(card) } catch (e: Exception) {}
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
